package com.example.eecotraffic;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.robinhood.ticker.TickerUtils;
import com.robinhood.ticker.TickerView;

import java.util.concurrent.TimeUnit;

public class simulation {
    public static Boolean allZeros(int a[]) {
        int i;
        boolean flag = true;
        for (i = 0; i < a.length; ++i)
            if (a[i] != 0)
                flag = false;
        return flag;
    }
    public static int total_real = 0;
    public static int total_model = 0;

    public static void main(String args[]) throws java.lang.InterruptedException {
        Boolean ut_model, rt_model;
        Boolean ut_real, rt_real;
        int[] upno_model = new int[6];
        int[] rno_model = new int[6];
        int[] upno_real = new int[6];
        int[] rno_real = new int[6];
        upno_model[0] = upno_real[0] = (int) (Math.random() * 15);
        rno_model[0] = rno_real[0] = (int) (Math.random() * 15);
        //int total_real = 0, total_model = 0;
        int emisu_model = 0, emisr_model = 0, i_model = 1, j_model = 0, k_model = 0, l;
        int emisu_real = 0, emisr_real = 0, i_real = 1, j_real = 0, k_real = 0;
        ut_model = rt_model = ut_real = rt_real = false;
        if (upno_model[0] > rno_model[0]) {
            ut_model = true;
            ut_real = true;
        }
        else {
            rt_model = true;
            rt_real = true;
        }
        int count_model = 0, count_real = 0;

        while (true) {
            count_model += 1;
            count_real += 1;
            TimeUnit.SECONDS.sleep(1);
            int random1 = (int) (Math.random() * 6);
            int random2 = (int) (Math.random() * 4);

            //REAL MODEL

            if (rt_real && count_real == 15) {
                rt_real = false;
                TimeUnit.SECONDS.sleep(2);
                ut_real = true;
                emisr_real = 0;
                emisu_real = 0;
                j_real = 0;
                k_real = 0;
                upno_real[0] = upno_real[0] + upno_real[1] + upno_real[2] + upno_real[3] + upno_real[4] + upno_real[5];
                rno_real[0] = rno_real[0] + rno_real[1] + rno_real[2] + rno_real[3] + rno_real[4] + rno_real[5];
                for (int m = 1; m < 6; ++m) {
                    upno_real[m] = 0;
                    rno_real[m] = 0;
                }
                count_real = 0;
                i_real = 1;
                System.out.println("Switching signals for real");
                continue;
            }
            if (ut_real && count_real == 15) {
                ut_real = false;
                TimeUnit.SECONDS.sleep(2);
                rt_real = true;
                emisr_real = 0;
                emisu_real = 0;
                j_real = 0;
                k_real = 0;
                upno_real[0] = upno_real[0] + upno_real[1] + upno_real[2] + upno_real[3] + upno_real[4] + upno_real[5];
                rno_real[0] = rno_real[0] + rno_real[1] + rno_real[2] + rno_real[3] + rno_real[4] + rno_real[5];
                for (int m = 1; m < 6; ++m) {
                    upno_real[m] = 0;
                    rno_real[m] = 0;
                }
                count_real = 0;
                i_real = 1;
                System.out.println("Switching signals for real");
                continue;
            }

            if (upno_real[j_real] == 0 && j_real != 3)
                while (upno_real[j_real] == 0 && j_real < 5) j_real++;
            if (rno_real[k_real] == 0 && k_real != 3)
                while (rno_real[k_real] == 0 && k_real < 5) k_real++;

            if (ut_real && !allZeros(upno_real))
                upno_real[j_real] -= 1;
            else if (rt_real && !allZeros(rno_real))
                rno_real[k_real] -= 1;

            emisu_real += upno_real[0] + upno_real[1] + upno_real[2] + upno_real[3] + upno_real[4] + upno_real[5];
            emisr_real += rno_real[0] + rno_real[1] + rno_real[2] + rno_real[3] + rno_real[4] + rno_real[5];

            if (count_real % 3 == 0) {
                if (rt_real == true) {
                    upno_real[i_real] += random1;
                    rno_real[i_real] += random2;
                }
                if (ut_real == true) {
                    rno_real[i_real] += random1;
                    upno_real[i_real] += random2;
                }
                i_real++;
            }

            total_real += emisr_real + emisu_real;
            System.out.println("Real:" + total_real);

            //OUR MODEL

            if (ut_model == true && emisr_model >= emisu_model && count_model >= 6 || ut_model == true && allZeros(upno_model) || count_model == 15) {
                ut_model = false;
                TimeUnit.SECONDS.sleep(2);
                rt_model = true;
                emisr_model = 0;
                emisu_model = 0;
                j_model = 0;
                k_model = 0;
                upno_model[0] = upno_model[0] + upno_model[1] + upno_model[2] + upno_model[3] + upno_model[4] + upno_model[5];
                rno_model[0] = rno_model[0] + rno_model[1] + rno_model[2] + rno_model[3] + rno_model[4] + rno_model[5];
                for (int m = 1; m < 6; ++m) {
                    upno_model[m] = 0;
                    rno_model[m] = 0;
                }
                count_model = 0;
                i_model = 1;
                System.out.println("Switching signals for model");
                continue;
            }
            if (rt_model == true && emisu_model >= emisr_model && count_model >= 6 || rt_model == true && allZeros(rno_model) || count_model == 15) {
                rt_model = false;
                TimeUnit.SECONDS.sleep(2);
                ut_model = true;
                emisr_model = 0;
                emisu_model = 0;
                j_model = 0;
                k_model = 0;
                upno_model[0] = upno_model[0] + upno_model[1] + upno_model[2] + upno_model[3] + upno_model[4] + upno_model[5];
                rno_model[0] = rno_model[0] + rno_model[1] + rno_model[2] + rno_model[3] + rno_model[4] + rno_model[5];
                for (int m = 1; m < 6; ++m) {
                    upno_model[m] = 0;
                    rno_model[m] = 0;
                }
                count_model = 0;
                i_model = 1;
                System.out.println("Switching signals for model");
                continue;
            }

            if (upno_model[j_model] == 0 && j_model != 3)
                while (upno_model[j_model] == 0 && j_model < 5) j_model++;
            if (rno_model[k_model] == 0 && k_model != 3)
                while (rno_model[k_model] == 0 && k_model < 5) k_model++;
            if (ut_model)
                upno_model[j_model] -= 1;
            else
                rno_model[k_model] -= 1;

            emisu_model += upno_model[0] + upno_model[1] + upno_model[2] + upno_model[3] + upno_model[4] + upno_model[5];
            emisr_model += rno_model[0] + rno_model[1] + rno_model[2] + rno_model[3] + rno_model[4] + rno_model[5];

            if (count_model % 3 == 0) {
                if (rt_model == true) {
                    upno_model[i_model] += random1;
                    rno_model[i_model] += random2;
                }
                if (ut_model == true) {
                    rno_model[i_model] += random1;
                    upno_model[i_model] += random2;
                }
                i_model++;
            }

            total_model += emisr_model + emisu_model;
            System.out.println("Model:" + total_model);
        }
    }
}

