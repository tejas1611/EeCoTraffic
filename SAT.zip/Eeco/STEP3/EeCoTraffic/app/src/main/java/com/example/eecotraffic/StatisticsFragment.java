package com.example.eecotraffic;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;

import com.robinhood.ticker.TickerUtils;
import com.robinhood.ticker.TickerView;

public class StatisticsFragment extends Fragment {
    private static final String TAG = "Statistics";
    public static TickerView tickerViewCarbonModel, tickerViewCarbonSaved, tickerViewCarbonReal;
    private PageViewModel pageViewModel;



    public StatisticsFragment() {
        // Required empty public constructor
    }

    /**
     * @return A new instance of fragment SpeedDialFragment.
     */
    public static StatisticsFragment newInstance() {
        return new StatisticsFragment();
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
            View root = inflater.inflate(R.layout.fragment_statistics, container, false);
            tickerViewCarbonModel = root.findViewById(R.id.tickerViewCarbonModel);
            tickerViewCarbonReal = root.findViewById(R.id.tickerViewCarbonReal);
            tickerViewCarbonSaved = root.findViewById(R.id.tickerViewCarbonSaved);
            tickerViewCarbonModel.setCharacterLists(TickerUtils.provideNumberList());
            tickerViewCarbonReal.setCharacterLists(TickerUtils.provideNumberList());
            tickerViewCarbonSaved.setCharacterLists(TickerUtils.provideNumberList());
            tickerViewCarbonModel.setText("70980");
            tickerViewCarbonReal.setText("107206");
            tickerViewCarbonSaved.setText("36226");
            return root;
        }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        pageViewModel = ViewModelProviders.of(this).get(PageViewModel.class);
        pageViewModel.setIndex(TAG);
    }
}
